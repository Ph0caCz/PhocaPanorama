DROP TABLE IF EXISTS `#__phocapanorama_items`;
DROP TABLE IF EXISTS `#__phocapanorama_categories`;
